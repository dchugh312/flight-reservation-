# Airline-Reservation-System

Our OOP Endterm Project Topic: Airline Reservation System.

Our project implements a system for the purchase of flight tickets to different cities of the world. To implement this project, we used technology of Java, PostgreSQL. 

Project consists of 8 classes including main class: 

  1) Application.java (main) 
  2) Airplane.java 
  3) Flight.java 
  4) Ticket.java 
  5) Passenger.java 
  6) ChooseTicket.java 
  7) BuyTicket.java
